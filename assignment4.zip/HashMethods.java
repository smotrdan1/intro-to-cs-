
public interface HashMethods
{
    long hash( String x, int which );
    int getNumberOfFunctions( );
    void generateNewFunctions( );
}