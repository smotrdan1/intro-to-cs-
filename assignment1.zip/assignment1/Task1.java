/*
 * Task1
 *
 * Authentic author: <daniel smotrtisky >
 * I.D.: <324374131>
 * Last update: <11/11/2019>
 */

import java.util.Scanner;

public class Task1 {

    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);
        int a = myScanner.nextInt();
        //---------------write your code BELOW this line only!--------------
        int b = myScanner.nextInt();
        int q = myScanner.nextInt();
        int r = myScanner.nextInt();
        int sum;
        if ((b != 0) & (b > r)) 
        {
            sum = b * q + r;


            if (a == sum) {
                System.out.println("yes");
            } else
                System.out.println("no");
        }
        if((b == 0) | (b < r))
            System.out.println("no");

        //---------------write your code ABOVE this line only!--------------
        }


    }
