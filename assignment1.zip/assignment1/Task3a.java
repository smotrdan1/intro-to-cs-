/*
 * Task3a
 *
 * Authentic author: <daniel smotritsky>
 * I.D.: <324374131>
 * Last update: <11/11/2019>
 */

import java.util.Scanner;

public class Task3a {

    public static void main(String[] args) {
        //---------------write your code BELOW this line only!--------------
        Scanner myScanner = new Scanner(System.in);
        int n = myScanner.nextInt();

        int hezka=2;
        while(n>1){
             hezka=hezka*2;
            n=n-1;
}
        
          System.out.println(hezka);
        //---------------write your code ABOVE this line only!--------------
        }


    }
