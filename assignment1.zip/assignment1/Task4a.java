/*
 * Task4a
 *
 * Authentic author: <daniel smotrtisky>
 * I.D.: <324374131>
 * Last update: <11/11/2019>
 */

import java.util.Scanner;

public class Task4a {

    public static void main(String[] args) {


        //---------------write your code BELOW this line only!--------------
        Scanner myScanner = new Scanner(System.in);
        int number = myScanner.nextInt();
        boolean prime = true;
        int div = 2;
        while (div * div <= number & prime) {
            if (number % div == 0) {
                prime = false;
            }
            div++;
        }
        if (prime) {
            System.out.println("prime");
        } else {
            System.out.println("composite");
        }


        //---------------write your code ABOVE this line only!--------------
    }
}

