/*
 * Task4d
 *
 * Authentic author: <daniel smotritsky>
 * I.D.: <324374131>
 * Last update: <11/11/2019>
 */

import java.util.Scanner;

public class Task4d {

    public static void main(String[] args) {

        //---------------write your code BELOW this line only!--------------
        Scanner myScanner = new Scanner(System.in);
        int n = myScanner.nextInt();
        int s=0;
        int d;

            n--;
            while ((n % 2) == 0) {
                n = n / 2;
                s++;
            }
        d=n;
           System.out.println(s);
        if (d!=1) {
            System.out.println(d);
        }
        else {
            System.out.println(0);
        }





        //---------------write your code ABOVE this line only!--------------


   }

           }

