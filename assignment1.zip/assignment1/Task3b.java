/*
 * Task3b
 *
 * Authentic author: <daniel smotrtisky>
 * I.D.: <324374131>
 * Last update: <11/11/2019>
 */

import java.util.Scanner;

public class Task3b {

    public static void main(String[] args) {

        //---------------write your code BELOW this line only!--------------
        Scanner myScanner = new Scanner(System.in);
        int n = myScanner.nextInt();
        int k = myScanner.nextInt();
        int leftover = 1;//is the sum of the % leftover
        for (int i = 0; i < n; i++) {//the loop calculates the leftover
            leftover = ((2 % k) * (leftover)) % k;
        }
        leftover = leftover % k;//last calculation as stated in the terms
        System.out.println(leftover);


        //---------------write your code ABOVE this line only!--------------
    }
}

