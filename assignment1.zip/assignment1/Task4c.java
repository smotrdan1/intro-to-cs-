/*
 * Task4c
 *
 * Authentic author: <daniel smotritsky>
 * I.D.: <324374131>
 * Last update: <11/12/2019>
 */

import java.util.Scanner;

public class Task4c {

    public static void main(String[] args) {

        //---------------write your code BELOW this line only!--------------
        Scanner myScanner = new Scanner(System.in);
        int n = myScanner.nextInt();
        int b = (int) (Math.random() * ((n - 1) - 2) + 2);
         System.out.println(b);
//---------------write your code ABOVE this line only!--------------

    }}