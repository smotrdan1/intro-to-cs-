/*
 * Task4f
 *
 * Authentic author: <daniel smotritsky>
 * I.D.: <324374131>
 * Last update: <11/11/2019>
 */

import java.util.Scanner;

public class Task4f {

    public static void main(String[] args) {

        //---------------write your code BELOW this line only!--------------
        Scanner myScanner = new Scanner(System.in);
        int n = myScanner.nextInt();
        int s = myScanner.nextInt();
        int d = myScanner.nextInt();
        int k = myScanner.nextInt();
        int b;
        int leftover = 1;                         //sums up the leftover after %
        boolean op1 = true;//condition for the eternal loops
        boolean op3=true;//condition for the external loop


        for (int p = 0; (p < k)&(op3); k++) { // if op3 is not met no need to continue the checking
            b = (int) (Math.random() * ((n - 1) - 2) + 2);


            for (int j = 0; (j < d) & (op1); j++) {//first condition
                leftover = (b % n) * (leftover % n);
            }
            leftover = leftover % n;
            if (leftover == 1) {
                op1 = false;
            }

            leftover = 1;

            int pOFI = 1;//sums up the power of i

            for (int i = 0; (i <= (s - 1) & (op1)); i++) {//second condition checked for each "i"
                int totalpower;
                totalpower = 1;
                leftover = 1;
                for (int q = 0; q < i; q++) {
                    pOFI = pOFI * 2;
                }
                totalpower = pOFI * d;
                pOFI = 1;
                for (int j = 0; j < totalpower; j++) {
                    leftover = ((b % n) * leftover) % n;
                }
                leftover = leftover % n;

                if (leftover == (n - 1)) {
                    op1 = false;
                }
            }
            if ((op1)) {
                System.out.println(b + " is a witness." + n + " is composite. ");
                op3 = false;
            } else {
                System.out.println("We assume " + n + " is prime. ");
                op3 = false;
            }


        }
        //---------------write your code ABOVE this line only!--------------

    }
}

