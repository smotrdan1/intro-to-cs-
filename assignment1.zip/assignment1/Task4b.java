/*
 * Task4d
 *
 * Authentic author: <daniel smotrtisky>
 * I.D.: <324374131>
 * Last update: <11/11/2019>
 */
import java.util.Scanner;

public class Task4b {

    public static void main(String[] args) {


        //---------------write your code BELOW this line only!--------------
        Scanner myScanner = new Scanner(System.in);
        int n = myScanner.nextInt();
        int total = 0;
        for (int number = 2; number <= n; number++) {
            boolean prime = true;
            for (int div = 2; div * div <= number & prime; div++) {
                if (number % div == 0)
                    prime = false;
            }
            if (prime)
                total++;


        }
        System.out.println(total);

        //---------------write your code ABOVE this line only!--------------}
    }
}
