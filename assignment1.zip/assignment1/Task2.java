/*
 * Task2
 *
 * Authentic author: <daniel smotrtisky>
 * I.D.: <324374131>
 * Last update: <11/11/2019>
 */

import java.util.Scanner;

public class Task2 {

    public static void main(String[] args) {
        //---------------write your code BELOW this line only!--------------
        Scanner myScanner = new Scanner(System.in);
        int a = myScanner.nextInt();

        int b = myScanner.nextInt();
        int n;
        if (b>a) {
            n = (int) (Math.random() * ((b - a) + 1)) + a;

            }

            //---------------write your code ABOVE this line only!--------------
        }


    }
