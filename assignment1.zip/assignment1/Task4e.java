/*
 * Task4e
 *
 * Authentic author: <daniel smotrtisky>
 * I.D.: <324374131>
 * Last update: <11/11/2019>
 */

import java.util.Scanner;

public class Task4e {

    public static void main(String[] args) {
        //---------------write your code BELOW this line only!--------------
        Scanner myScanner = new Scanner(System.in);
        int n = myScanner.nextInt();
        int b = myScanner.nextInt();
        int s = myScanner.nextInt();
        int d = myScanner.nextInt();
        int leftover = 1;                         //sums up the left over after %
        boolean op1 = true;//condition for the loops


        for (int j = 0; (j < d)&(op1); j++) { // check for the first term(op1-if not true no need to continue checking)
            leftover = (b % n) * (leftover % n);
        }
            leftover = leftover % n;
            if (leftover == 1) {
                op1 = false;
            }

        leftover = 1;

        int pOFI = 1;

        for (int i = 0; (i <= (s-1)&(op1)); i++) {//check of the second term(op1-if not true no need to continue checking)
           int totalpower;
           totalpower=1;
           leftover=1;
            for (int k = 0; k <i; k++) { //internal loop calculates the the total power
                pOFI = pOFI * 2;
            }
             totalpower = pOFI * d;
            pOFI=1;
            for (int j = 0; j < totalpower; j++) {//internal loop calculates the leftover with the power "i"
                leftover = ((b % n) * leftover )% n;
            }
            leftover = leftover % n;

        if (leftover == (n - 1)) {
            op1 = false;
        }
    }
     if ((op1))
         System.out.println(b+" is a witness." +n+" is composite. ");
     else
         System.out.println("We assume " +n +" is prime. ");





        //---------------write your code ABOVE this line only!--------------
    }


}