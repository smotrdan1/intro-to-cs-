
/*
 I, <daniel smotritsky> (<324374131>), assert that the work I submitted is entirely my own.
 I have not received any part from any other student in the class, nor did I give parts of it for use to others.
 I realize that if my work is found to contain code that is not originally my own, a
 formal case will be opened against me with the BGU disciplinary committee.
*/

// Last Update: 4/12/2019

public class Assignment2 {

    /*--------------------------------------------------------
       Part a: instance representation & Solution verification
      -------------------------------------------------------
     */

    // Task 1
    public static boolean hasFlight(int[][] flights, int i, int j) {
        boolean hasFlight = false;
        for (int k = 0; k < flights[i].length & (!hasFlight); k++) {


            if (flights[i][k] == j)
                hasFlight = true;
        }


        return hasFlight;
    }

    // Task 2
    public static boolean isLegalInstance(int[][] flights) {
        boolean isLegalInstance = true;

        if (flights == null || flights.length <= 1) {//flights is not incorrect
            isLegalInstance = false;
        }
        for (int i = 0; isLegalInstance && i < flights.length; i = i + 1) {//flights[i] is empty
            if (flights[i] == null) {
                isLegalInstance = false;
            }
            for (int j = 0; isLegalInstance && j < flights[i].length; j = j + 1) { //flights includes wrong numbers
                int First = flights[i][j];
                if (First >= flights.length | First < 0) {
                    isLegalInstance = false;
                }
            }
        }
        for (int i = 0; isLegalInstance && i < flights.length; i = i + 1) {//first condition
            for (int j = 0; isLegalInstance && j < flights[i].length; j = j + 1) {
                int First= flights[i][j];
                if (!hasFlight(flights, First, i)) {
                    isLegalInstance = false;
                }
            }
        }
        for (int i = 0; isLegalInstance && i < flights.length; i = i + 1) {//second condition
            for (int j = 0; isLegalInstance && j < flights[i].length; j = j + 1) {
                int First = flights[i][j];
                if (First == i) {
                    isLegalInstance = false;
                }
            }
        }
        return isLegalInstance;
    }

    // Task 3
    public static boolean isSolution(int[][] flights, int[] tour) {
        boolean iftourOK = true;
        if ((tour == null) || (tour.length != flights.length)) {
            throw new IllegalArgumentException("illegal length of tour array");
        }
        for (int i = 0; i < tour.length; i = i + 1) {
            if (tour[i] < 0 || tour[i] >= flights.length) {
                throw new IllegalArgumentException("illegal value range");
            }
        }
        for (int i = 0; i < tour.length - 1 & iftourOK; i = i + 1) {


            if (!hasFlight(flights, tour[i], tour[i + 1]))// tour first condition
                iftourOK = false;


        }
        if (!hasFlight(flights, tour[tour.length - 1], tour[0]))// tour second condition
            iftourOK = false;

        return iftourOK;
    }

	/*------------------------------------------------------
	  Part b: Express the problem as a CNF formula, solve
	  it with a SAT solver, and decode the solution
	  from the satisfying assignment
	  -----------------------------------------------------
	 */

    // Task 4
    public static int[][] atLeastOne(int[] vars) {
        int n = vars.length;
        int[][] cnf = new int[1][n];
        for (int i = 0; i < n; i++) {
            cnf[0][i] = vars[i];
        }
        return cnf;
    }

    // Task 5
    public static int[][] atMostOne(int[] vars) {
        int n = vars.length;
        int cnfsize = n * (n - 1) / 2;
        int currIndex = 0;
        int cnf[][] = new int[cnfsize][2];
        for (int i = 0; i < vars.length; i = i + 1) {
            for (int j = i + 1; j < vars.length; j = +j + 1, currIndex++) {
                int[] clause = {-vars[i], -vars[j]};
                cnf[currIndex] = clause;
            }
        }
        return cnf;
    }

    // Task 6
    public static int[][] append(int[][] arr1, int[][] arr2) {
        int sizeOFarr3 = arr1.length + arr2.length;//check the size of the arr


        int arr3[][] = new int[sizeOFarr3][];//adding the first arr to arr3
        for (int i = 0; i < arr1.length; i = i + 1) {
            arr3[i] = arr1[i];

        }
        int j = 0;
        for (int i = arr1.length; i < sizeOFarr3; i = i + 1) {//adding the second arr  to arr3
            arr3[i] = arr2[j];
            j = j+1;
        }
        return arr3;
    }

    // Task 7
    public static int[][] exactlyOne(int[] vars) {

        int cnf1[][] ;
        cnf1 = append(atLeastOne(vars),atMostOne(vars));



        return cnf1;
    }

    // Task 8
    public static int[][] diff(int[] I1, int[] I2) {
        int cnf[][] = new int[I1.length][2];
        for (int i = 0; i < I1.length; i = i + 1) {

                cnf[i][0] = -I1[i];
                cnf[i][1] = -I2[i];

        }

        return cnf;

    }

    // Task 9
    public static int[][] createVarsMap(int n) {
        int cnf[][] = new int[n][n];//size of the cnf to be returned
        for (int j = 0; j < n; j = j + 1) {
            for (int i = n*j; i < n+n*j; i = i + 1) {
                cnf[j][i-n*j] =i+1;//adding the numbers to cnf

            }
        }
        return cnf;
    }

    // Task 10
    public static int[][] declareInts(int[][] map) {


        int cnf[][] = {};
        for (int i = 0; i < map.length; i = i + 1) {

            int cnf1[][] = exactlyOne(map[i]);
            cnf = append(cnf, cnf1);

        }

        return cnf;
    }

    // Task 11
    public static int[][] allDiff(int[][] map) {
        int cnf[][] = new int[0][];
        for (int i = 0; i < map.length - 1; i = i + 1) {
            for (int j = i + 1; j < map.length ; j = j + 1) {
                int[][] temp = diff(map[i], map[j]);//making sure diffrent
                cnf = append(cnf, temp);

            }
        }
        return cnf;
    }

    // Task 12
    public static int[][] allStepsAreLegal(int[][] flights, int[][] map) {
        int cnf[][] = new int[0][];
        for (int i = 0; i < map.length - 1; i = i + 1) {
            for (int j = 0; j < map.length; j = j + 1) {
                for (int k = 0; k < map.length; k = k + 1) {
                    if (!hasFlight(flights, j, k)) {//if !hasflights , change the variables in map and enter to cnf
                        int[][] clause = {{-(map[i][j]), -(map[i + 1][k])}};
                        int cnf1[][] = clause;
                        cnf = append(cnf, cnf1);


                    }
                }
            }

        }
        for (int j = 0; j < map.length; j = j + 1) {
            for (int k = 0; k < map.length; k = k + 1) {
                if (!hasFlight(flights, j, k)) {//if !hasflights , change the first and last variables in map and enter to cnf
                    int[][] clause = {{-(map[map.length - 1][j]), -(map[0][k])}};
                    int cnf1[][] = clause;
                    cnf = append(cnf, cnf1);

                }

            }
        }
        return cnf;
    }
    // Task 13
    public static void encode(int[][] flights, int[][] map) {

        if (map == null || !isLegalInstance(flights) || map.length != flights.length)
            throw new IllegalArgumentException("incorrect flights instance");
        int i=1;
        for (int p = 0; p < map.length; p = p + 1) {
            for (int j = 0; j < map.length; j = j + 1,i=i+1) {
                if (map[p][j] != i) {//if
                    throw new IllegalArgumentException("the mapvars is wrong");
                }

                if (map[p].length != flights.length) {
                    throw new IllegalArgumentException("the mapvars is wrong");
                }
            }
        }
        int[][] cnf = append(append(declareInts(map), allDiff(map)), allStepsAreLegal(flights, map));//cnf to be returned , after all athe appends
        SATSolver.init(flights.length*flights.length);
        SATSolver.addClauses(cnf);
    }


    // Task 14
    public static int[] decode(boolean[] assignment, int[][] map) {
        if(assignment.length != (map.length * map.length + 1)) {//checking is array is N^2+1
            throw new IllegalArgumentException("wrong size of array");
        }
        int[] result = new int[map.length];//the array to be returned
        int index= 0;//index for the result array
        for(int i = 0; i < assignment.length; i = i + 1) {
            if (assignment[i]) {
                result[index] = ((i - 1) % map.length);
                index = index + 1;
            }
        }


        return result;
    }

    // Task 15
    public static int[] solve(int[][] flights) {
        // Add your code here
        if (!isLegalInstance(flights))
            throw new IllegalArgumentException("false flights array");//if the array has false input
        int  [][]map =createVarsMap(flights.length);

        encode(flights,map);
        boolean [] assignment=SATSolver.getSolution();
        if (assignment==null)
            throw new IllegalArgumentException("timeout");//if timeout happens
        else
        if (assignment.length==0){
            return null;
        }
        int[]s=decode(assignment,map);
        if (!isSolution(flights,s)) {//if an illegal anwser is returned
            throw new IllegalArgumentException("illegal anwser");

        }
        return s;
    }

    // Task 16
    public static boolean solve2 ( int[][] flights, int s, int t){
        // Add your code here
        return false;
    }
}



