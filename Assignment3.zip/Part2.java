/*
I, <daniel smotritsky> (<324374131>), assert that the work I submitted is entirely my own.
I have not received any part from any other student in the class,
nor did I give parts of it for use to others.
I realize that if my work is found to contain code that is not originally my own,
 a formal case will be opened against me with the BGU disciplinary committee.
*/
class Part2 {
   //task2.1
    public static boolean change(int[] coins, int n) {
        boolean ans;
        ans = change1recursion(coins, n, 0);
        return ans;
    }

    public static boolean change1recursion(int[] coins, int n, int i) {
        boolean ans = false;
        if (n == 0)
            ans = true;
        else if (n < 0 | i == coins.length)
            ans = false;
        else
            ans = change1recursion(coins, n - coins[i], i) || change1recursion(coins, n, i + 1);
        return ans;
    }
        //task2.2
    public static boolean changeLimited(int[] coins, int n, int numOfCoinsToUse) {
        boolean ans = false;
        ans = changeLimitedRecursion(coins, n, 0, numOfCoinsToUse);
        return ans;
    }
//checking if we can get the 'n' by the exact limited change
    public static boolean changeLimitedRecursion(int[] coins, int n, int i, int numOfCoinsToUse) {
        boolean ans = false;
        if ((n == 0) & (numOfCoinsToUse == 0))//return true if we can make change and in the right number of coins
            ans = true;
        else if (n < 0 | i >= coins.length)
            ans = false;
        else
            ans = changeLimitedRecursion(coins, n - coins[i], i , numOfCoinsToUse - 1) || changeLimitedRecursion(coins, n, i + 1, numOfCoinsToUse);//only if we minimize the n , if we start the change, then we used a coin.
        return ans;
    }
     //task 2.3
    public static void printChangeLimited(int[] coins, int n, int numOfCoinsToUse) {

        PrintchangeLimitedRecursion(coins, n, 0, numOfCoinsToUse,"");

    }
//checking if we can get the 'n' by the exact limited change and if so , we print it.
    public static boolean PrintchangeLimitedRecursion(int[] coins, int n, int i, int numOfCoinsToUse,String str) {
        boolean ans = false;


        if ((n == 0) & (numOfCoinsToUse == 0)){//return true if we can make change and in the right number of coins
        if(str!="")
            System.out.println(str.substring(0,str.length()-1));
        ans =true;
        }
        else if (n < 0 || i >= coins.length)
            ans=false;

        else
            ans = PrintchangeLimitedRecursion(coins, n - coins[i], i , numOfCoinsToUse - 1, str+coins[i]+",") || PrintchangeLimitedRecursion(coins, n, i + 1, numOfCoinsToUse,str+"");
        return ans;
    }
        //task2.4
    public static int countChangeLimited(int[] coins, int n, int numOfCoinsToUse){
        int ans = 0;
        ans =CountchangeLimitedRecursion(coins,n,0,numOfCoinsToUse);
        return ans;
    }
    //counting and returning the diffrent options of change we can get.
    public static int CountchangeLimitedRecursion(int[] coins, int n, int i, int numOfCoinsToUse) {
        int ans = 0;
        if ((n == 0) & (numOfCoinsToUse == 0)) {//return true if we can make change and in the right number of coins
            ans = 1;
        } else if (n < 0 | i >= coins.length) {
            ans = 0;
        } else


            ans = CountchangeLimitedRecursion(coins, n - coins[i], i , numOfCoinsToUse - 1) + CountchangeLimitedRecursion(coins, n, i + 1, numOfCoinsToUse);//only if we minimize the n , if we start the change, then we used a coin.

        return ans;
    }
                //task 2.5
    public static void printAllChangeLimited(int[] coins, int n, int numOfCoinsToUse){
        PrintAllchangeLimitedrecursion(coins,n,0,numOfCoinsToUse,"");
    }
    //counting and printing the diffrent options of change we can get.
    public static int PrintAllchangeLimitedrecursion(int[] coins, int n, int i, int numOfCoinsToUse,String str) {
        int ans;
        if ((n == 0) & (numOfCoinsToUse == 0)){//retrn true if we can make change and in the right number of coins
          if (str!="")
            System.out.println(str.substring(0,str.length()-1));
        ans=1;
        }
        else if (n < 0 | i >= coins.length)
            ans=0;

        else
            ans = PrintAllchangeLimitedrecursion(coins, n - coins[i], i , numOfCoinsToUse - 1, str+coins[i]+",") + PrintAllchangeLimitedrecursion(coins, n, i + 1, numOfCoinsToUse,str+"");
        return ans;
    }
    //task 2.6
    public static int changeInCuba(int cuc){
        int ans = 0;
        int [] coins={ 1,3,3,5,9,10,15,20,30,50,60,100,150,300};//the cuc and cup converted to cuc
        ans=changeInCubarecursion(coins,cuc*3,0);
        return ans;
    }
    //counting and printing the difrrent options of change we can get.
public static int changeInCubarecursion( int []coins,int n, int i){
    int ans=0 ;
    if ((n == 0) ) {//return true if we can make change and in the right number of coins
        ans = 1;
    } else if (n < 0 | i >= coins.length) {
        ans = 0;
    } else
        ans=changeInCubarecursion(coins,n-coins[i],i)+changeInCubarecursion(coins,n,i+1);


    return ans;
}
    public static void main(String[] args){
        //tests for part 2.1
         int []changee1 = {1,5,10};
         int n = 7;
         System.out.println("change test 1:expected true, got " + change(changee1,n));
         int []cchange2 = {2,20,10,100};
         n = 15;
         System.out.println("change test 2: expected false, got " + change(cchange2,n)+"\n");

        // tests for part 2.2
         int []changeLimited1 = {1,12,17,19};
         n = 20;
        int numOfCoinsToUse = 2;
         System.out.println("ChangeLimited test 1: expected true, got " + changeLimited(changeLimited1,n ,numOfCoinsToUse));
         int []changeLimited2 = {5,7,12};
         n = 8;
         numOfCoinsToUse = 2;
         System.out.println("ChangeLimited test 2: expected false, got " + changeLimited(changeLimited2,n ,numOfCoinsToUse));
         int []changeLimited3 = {1,7,12,10};
         n = 10;
         numOfCoinsToUse = 5;
         System.out.println("ChangeLimited test 3: expected false, got " + changeLimited(changeLimited3,n ,numOfCoinsToUse)+"\n");

        // tests for part 2.3
         int []printChangeLimited1 = {1,2,3};
         n = 4;
         numOfCoinsToUse = 2;
         System.out.println("PrintChangeLimited test 1: expected 2,2 or 1,3 , got ");
         printChangeLimited(printChangeLimited1,n ,numOfCoinsToUse);
         int []printChangeLimited2 = {1,7,12};
         n = 10;
         numOfCoinsToUse = 5;
         System.out.println("PrintChangeLimited test 2: expected printing nothing, got ");
         printChangeLimited(printChangeLimited2,n ,numOfCoinsToUse);
         System.out.println("");

        //tests for part 2.4
        int []countChangeLimited1 = {1,2,3};
         n = 4;
         numOfCoinsToUse = 2;
         System.out.println("CountChangeLimited test 1: expected 2, got " + countChangeLimited(countChangeLimited1,n ,numOfCoinsToUse));
         int []countChangeLimited2 = {5,10,20,50,100};
         n = 100;
         numOfCoinsToUse = 5;
         System.out.println("CountChangeLimited test 2: expected 3, got " + countChangeLimited(countChangeLimited2,n ,numOfCoinsToUse));
         int []countChangeLimited3 ={5,10,50};
         n = 65;
         numOfCoinsToUse = 2;
         System.out.println("CountChangeLimited test 3: expected 0, got " + countChangeLimited(countChangeLimited3,n ,numOfCoinsToUse)+"\n");


        //tests for part 2.5
         int []printAllChangeLimited1 = {1,2,3};
         n = 4;
         numOfCoinsToUse = 2;
         System.out.println("PrintAllChangeLimited test 1: expected : \n 2,2 \n 1,3 \n or \n 1,3 \n 2,2 , got " );
         printAllChangeLimited(printAllChangeLimited1,n ,numOfCoinsToUse);
        int []printAllChangeLimited2 = {1,5,10,20};
         n = 13;
         numOfCoinsToUse = 2;
         System.out.println("PrintAllChangeLimited  test 2: expected printing nothing, got ");
         printAllChangeLimited(printAllChangeLimited2,n ,numOfCoinsToUse);
         System.out.println("");

        //tests for part 2.6
         System.out.println("ChangeInCuba 1");
         System.out.println(changeInCuba(1));
         System.out.println("ChangeInCuba 2");
         System.out.println(changeInCuba(2));
         System.out.println("ChangeInCuba 20");
         System.out.println(changeInCuba(20));
         System.out.println("ChangeInCuba 50");
         System.out.println(changeInCuba(50));
    }
}
