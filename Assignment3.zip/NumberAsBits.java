

/*
I, <daniel smotritsky> (<324374131>), assert that the work I submitted is entirely my own.
I have not received any part from any other student in the class,
nor did I give parts of it for use to others.
I realize that if my work is found to contain code that is not originally my own,
 a formal case will be opened against me with the BGU disciplinary committee.
*/
import java.math.BigInteger;
public class NumberAsBits {

    private Bit[] bits;

    public NumberAsBits(Bit[] bits) {
        if(bits==null)
            throw new IllegalArgumentException();
       Bit [] temp=new Bit[bits.length];// an array to save the value of bits for further use
      int i=0;
       while (i<bits.length)
       {
           if (bits[i]==null)
               throw new IllegalArgumentException();
            temp[i]=bits[i];
            i=i+1;
        }

        this.bits =temp;
    }


    public String toString() {
        String ans = "";
       BigInteger power = new BigInteger ("1"); // to multiply the power each time
        BigInteger temp = new BigInteger("0"); // a temporary for summing
        for (int i =bits.length-1; i >=0; i=i-1) { // conversion and summing
            temp =temp.add(BigInteger.valueOf(bits[i].toInt()).multiply(power));
            power = power.multiply(new BigInteger("2"));

        }
        ans = temp.toString();
        return ans;
    }

    public String base2() {
        String ans = "";
        for (int i = 0; i < bits.length; i++) {

          ans=ans+  bits[i].toString();
        }
        return ans;
    }


}
